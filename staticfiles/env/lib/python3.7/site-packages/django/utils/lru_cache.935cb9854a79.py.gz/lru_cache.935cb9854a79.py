from functools import lru_cache  # noqa

# Deprecate or remove this module when no supported version of Django still
# supports Python 2. Until then, keep it to allow pluggable apps to support
# Python 2 and Python 3 without raising a deprecation warning.
